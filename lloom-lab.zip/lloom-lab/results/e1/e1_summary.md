# E1 — coverage vs n (primary metric: specific coverage)

## bertopic
| n | runs | generic mean±std | specific mean±std | CV(specific) |
|---|---|---|---|---|
| 10 | 5 | 0.00 ± 0.00 | 0.00 ± 0.00 | — |
| 20 | 5 | 0.00 ± 0.00 | 0.02 ± 0.02 | 1.38 |
| 40 | 5 | 0.00 ± 0.00 | 0.00 ± 0.00 | — |
| 80 | 5 | 0.02 ± 0.04 | 0.01 ± 0.01 | 1.37 |
| 160 | 5 | 0.00 ± 0.00 | 0.00 ± 0.00 | — |

